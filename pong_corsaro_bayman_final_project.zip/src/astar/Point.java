/*
 * Point.java - Class Representation of a 2-Dimensional Point.
 * 
 * Bryant Pong
 * CSCI-4480
 * 11/18/14
 * 
 * Last Updated: 11/18/14 - 1:49 PM
 */

public class Point {
	
	// Private member variables:
	
	
	// Constructor for a Point Object:
	public Point(int x, int y) {
		
	} // End constuctor Point
	
} // End class definition Point
